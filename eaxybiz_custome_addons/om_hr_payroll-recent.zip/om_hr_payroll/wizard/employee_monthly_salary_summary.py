from odoo import models, fields, api, _
import xlwt
from io import BytesIO
import base64
from xlwt import easyxf
import datetime
from odoo.exceptions import UserError
from datetime import datetime
from dateutil.relativedelta import relativedelta
import pdb

MONTH_LIST = [('1', 'Jan'), ('2', 'Feb'), ('3', 'Mar'),
              ('4', 'Apr'), ('5', 'May'), ('6', 'Jun'),
              ('7', 'Jul'), ('8', 'Aug'), ('9', 'Sep'),
              ('10', 'Oct'), ('11', 'Nov'), ('12', 'Dec')]


class EmployeeMonthlySalarySummaryReport(models.TransientModel):
    _name = 'exployee.monthly.salary.summary.excel.wizard'
    _description = 'Employee Monthly Salary Summary Report'

    summary_file = fields.Binary('Employee Monthly Salary Summary Report')
    file_name = fields.Char('File Name')
    report_printed = fields.Boolean('Employee Monthly Salary Summary Report Printed')
    date = fields.Date("Date", default=fields.Date.context_today, required=False)
    partner_id = fields.Many2one('hr.employee', string='Employees', required=True)
    start_date = fields.Date("Start Date")
    end_date = fields.Date("End Date")


    def action_get_exployee_monthly_salary_summary_excel_wizard(self):
        workbook = xlwt.Workbook()
        worksheet1 = workbook.add_sheet('%s' % (self.partner_id.display_name))

        design_7 = easyxf('align: horiz left;font: bold 1;')
        design_8 = easyxf('align: horiz left;')
        design_9 = easyxf('align: horiz right;')
        design_10 = easyxf('align: horiz right; pattern: pattern solid, fore_colour red;')
        design_11 = easyxf('align: horiz right; pattern: pattern solid, fore_colour green;')
        design_12 = easyxf('align: horiz right; pattern: pattern solid, fore_colour gray25;')
        design_13 = easyxf('align: horiz right; font: bold 1; pattern: pattern solid, fore_colour gray25;')

        worksheet1.col(0).width = 2000
        worksheet1.col(1).width = 5000
        worksheet1.col(2).width = 5000
        worksheet1.col(3).width = 5500
        worksheet1.col(4).width = 5000
        worksheet1.col(5).width = 5000
        worksheet1.col(6).width = 5000
        worksheet1.col(7).width = 5000
        worksheet1.col(8).width = 5000
        worksheet1.col(9).width = 5500
        worksheet1.col(10).width = 3000

        rows = 0
        cols = 0
        row_pq = 0

        worksheet1.set_panes_frozen(True)
        worksheet1.set_horz_split_pos(rows + 1)
        worksheet1.set_remove_splits(True)

        col_1 = 0
        col_2 = 0

        worksheet1.write(rows, 2, 'EMPLOYEE PAYROLL MONTHLY SUMMARY', design_13)
        rows += 1
        worksheet1.write(rows, 1, 'FROM', design_7)
        worksheet1.write(rows, 2, self.start_date.strftime('%d-%m-%Y'), design_7)
        rows += 1
        worksheet1.write(rows, 1, 'TO', design_7)
        worksheet1.write(rows, 2, self.end_date.strftime('%d-%m-%Y'), design_7)
        rows += 1
        worksheet1.write(rows, 1, 'EMPLOYEE', design_7)
        worksheet1.write(rows, 2, self.partner_id.display_name, design_7)
        rows += 1
        worksheet1.write(rows, col_1, _('Sl.No'), design_7)
        col_1 += 1
        worksheet1.write(rows, col_1, _('Invoice Date'), design_7)
        col_1 += 1
        worksheet1.write(rows, col_1, _('Invoice No.'), design_7)
        col_1 += 1

        sl_no = 1
        row_pq = row_pq + 1
        mr_num = []
        res = []
        for record in self:
            # ('indent_id.state', 'not in', ('draft', 'cancel', 'reject'))
            domain = [
                ('employee_id', '>=', record.partner_id.id),
                ('date_from', '>=', record.start_date),
                ('date_to', '<=', record.end_date),
            ]
            domain1 = [
                ('date_from', '>=', record.start_date),
                ('date_to', '<=', record.end_date),
            ]
            if record.partner_id:
                print("domain is calling=======================================",domain)
                material = record.env['hr.payslip'].sudo().search(domain)
                for invoice in material:
                    ref_date1 = invoice.date_from
                    updated_date = invoice.date_to
                    import datetime
                    d11 = str(ref_date1)
                    dt21 = datetime.datetime.strptime(d11, '%Y-%m-%d')
                    date1 = dt21.strftime("%d/%m/%Y")
                    d22 = str(updated_date)
                    dt22 = datetime.datetime.strptime(d22, '%Y-%m-%d')
                    invoice_updated_date = dt22.strftime("%d/%m/%Y")
                    worksheet1.write(row_pq, 0, sl_no, design_8)
                    worksheet1.write(row_pq, 1, date1, design_8)
                    worksheet1.write(row_pq, 2, invoice_updated_date, design_8)
                    # worksheet1.write(row_pq, 1, invoice.slip_id.employee_id.display_name, design_8)
                    # worksheet1.write(row_pq, 2, invoice.slip_id.contract_id.display_name, design_8)
                    # worksheet1.write(row_pq, 3, invoice.indent_id.responsible.name, design_8)
                    # worksheet1.write(row_pq, 4, invoice.indent_id.responsible.department_id.name, design_8)
                    sl_no += 1
                    row_pq += 1
            else:
                material = record.env['hr.payslip'].sudo().search(domain1)
                for invoice in material:
                    ref_date1 = invoice.date_from
                    updated_date = invoice.date_to
                    import datetime
                    d11 = str(ref_date1)
                    dt21 = datetime.datetime.strptime(d11, '%Y-%m-%d')
                    date1 = dt21.strftime("%d/%m/%Y")
                    d22 = str(updated_date)
                    dt22 = datetime.datetime.strptime(d22, '%Y-%m-%d')
                    invoice_updated_date = dt22.strftime("%d/%m/%Y")
                    # mr_num.append(invoice.slip_id.name)
                    worksheet1.write(row_pq, 0, sl_no, design_8)
                    worksheet1.write(row_pq, 1, date1, design_8)
                    worksheet1.write(row_pq, 2, invoice_updated_date, design_8)

                    #     if i not in res:
                    #         res.append(i)
                    # # for material_requistation_number in res:
                    # #     print(material_requistation_number)
                    # for material in material_requistation_number:
                    #     worksheet1.write(row_pq, 1, material_requistation_number, design_8)
                    #     # worksheet1.write(row_pq, 3, invoice.indent_id.responsible.name, design_8)
                    #     # worksheet1.write(row_pq, 4, invoice.indent_id.responsible.department_id.name, design_8)
                    #     worksheet1.write(row_pq, 2, invoice.indent_id.request_raised_for.name, design_8)
                    #     worksheet1.write(row_pq, 3, invoice.indent_id.request_raised_for.department_id.name, design_8)
                    #     worksheet1.write(row_pq, 4, invoice.product_id.name, design_8)
                    #     worksheet1.write(row_pq, 5, date1, design_8)
                    #     worksheet1.write(row_pq, 6, invoice.product_uom_qty, design_9)
                    #     worksheet1.write(row_pq, 7, invoice.product_uom_qty, design_9)
                    #     if invoice.indent_id.verified_date:
                    #         worksheet1.write(row_pq, 8, verified_date, design_8)
                    #     else:
                    #         worksheet1.write(row_pq, 8, '', design_8)
                    #     if invoice.indent_id.inward_date:
                    #         worksheet1.write(row_pq, 9, invoice.indent_id.inward_date, design_8)
                    #     else:
                    #         worksheet1.write(row_pq, 9, 'NIL', design_8)
                    #     # worksheet1.write(row_pq, 10, invoice_updated_date, design_8)
                    #     if invoice.indent_id.issued_date:
                    #         worksheet1.write(row_pq, 10, invoice.indent_id.issued_date, design_8)
                    #     else:
                    #         worksheet1.write(row_pq, 10, 'NIL', design_8)
                    #     worksheet1.write(row_pq, 11, '%.2f' % invoice.qty_shipped, design_8)
                    #     if invoice.indent_id.approved_by:
                    #         worksheet1.write(row_pq, 12, invoice.indent_id.approved_by.name, design_8)
                    #     else:
                    #         worksheet1.write(row_pq, 12, 'NIL', design_8)
                    #     # if invoice.indent_id.state == 'waiting_approval':
                    #     #     status = 'Waiting for Approval'
                    #     if invoice.indent_id.po_approved_by:
                    #         worksheet1.write(row_pq, 13, invoice.indent_id.po_approved_by, design_8)
                    #     else:
                    #         worksheet1.write(row_pq, 13, 'NIL', design_8)
                    #     if invoice.indent_id.store_incharge:
                    #         worksheet1.write(row_pq, 14, invoice.indent_id.store_incharge, design_8)
                    #     else:
                    #         worksheet1.write(row_pq, 14, 'NIL', design_8)
                    #     worksheet1.write(row_pq, 15, invoice.indent_id.state, design_9)
                    sl_no += 1
                    row_pq += 1

        fp = BytesIO()
        o = workbook.save(fp)
        fp.read()
        excel_file = base64.b64encode(fp.getvalue())
        self.write({'summary_file': excel_file, 'file_name': 'Employee Monthly Payroll Report - [ %s ].xls' % self.date,
                    'report_printed': True})
        fp.close()
        return {
            'view_mode': 'form',
            'res_id': self.id,
            'res_model': 'exployee.monthly.salary.summary.excel.wizard',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
            'context': self.env.context,
            'target': 'new',
        }
